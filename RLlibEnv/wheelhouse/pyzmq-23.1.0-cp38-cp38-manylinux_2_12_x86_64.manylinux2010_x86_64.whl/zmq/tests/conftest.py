"""pytest configuration and fixtures"""
